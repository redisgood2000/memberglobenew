# Member Globe Android APK build kit

This project wraps the live Member Globe website in an Android Trusted Web Activity (TWA). It keeps using the existing hosted app and backend; it does not create a second database.

Live site:
https://member-globe-t5uo18.v2.appdeploy.ai/

## Build an installable debug APK with GitHub Actions

1. Extract this ZIP.
2. Create a new empty repository on GitHub.
3. Upload all extracted files and folders to the repository (including `.github/workflows/build-android.yml`).
4. Open the repository's **Actions** tab and run **Build Member Globe Android APK**.
5. Wait for the workflow to finish, open the successful run, and download the **member-globe-debug-apk** artifact.
6. Extract the artifact ZIP and install `app-debug.apk` on your Android phone. If Android asks, allow installation from that source.

The APK is debug-signed for testing. It is not a Play Store release APK.

## Important notes

- The APK opens the hosted Member Globe site using Chrome's Trusted Web Activity support. Sign-in, the map, GPS sharing, profiles, approvals, and group chat remain on the existing backend.
- Full-screen TWA verification requires a Digital Asset Links file at `https://member-globe-t5uo18.v2.appdeploy.ai/.well-known/assetlinks.json` containing the signing certificate SHA-256 fingerprint. Until the domain is verified, Chrome may show browser UI around the app.
- The hosted app now has an installable web manifest and an opt-in push-notification flow. On Android, allow notifications when prompted. Actual background push delivery must be tested on the target phone/browser; the APK build itself does not prove push delivery.
- This starter project does not embed a private signing key. For a production/Play Store release, create and securely store your own release keystore and configure Digital Asset Links with its SHA-256 fingerprint.
